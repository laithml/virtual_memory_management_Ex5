//
// Created by Laith on 26/05/2022.
//
#include <cstdio>
#include <unistd.h>
#include <cstdlib>
#include <sys/fcntl.h>
#include "sim_mem.h"


sim_mem::sim_mem(char exe_file_name1[], char exe_file_name2[], char swap_file_name[], int text_size, int data_size, int bss_size, int heap_stack_size, int num_of_pages, int page_size, int num_of_process) {
    this->text_size = text_size;
    this->data_size = data_size;
    this->bss_size = bss_size;
    this->heap_stack_size = heap_stack_size;
    this->num_of_pages = num_of_pages;
    this->page_size = page_size;
    this->num_of_proc = num_of_process;
    int textPages = text_size / page_size;
    int swap_size = page_size * (num_of_pages - textPages);
    int swapPage = swap_size / page_size;

    if ((this->swapfile_fd = open(swap_file_name, O_CREAT | O_RDWR | O_TRUNC, 0666)) == -1) {
        perror("can't open the file");
        this->sim_mem::~sim_mem();
        exit(EXIT_FAILURE);
    }
    page_table = (page_descriptor **) malloc(num_of_process * sizeof(page_descriptor));
    if (num_of_process == 2) {
        if ((this->program_fd[0] = open(exe_file_name1, O_RDONLY)) == -1 || (this->program_fd[1] = open(exe_file_name2, O_RDONLY)) == -1) {
            perror("can't open the file");
            this->sim_mem::~sim_mem();
            exit(EXIT_FAILURE);
        }
        page_table[0] = new page_descriptor[num_of_pages];
        page_table[1] = new page_descriptor[num_of_pages];
    }
    if (num_of_process == 1) {
        if ((this->program_fd[0] = open(exe_file_name1, O_RDONLY)) == -1) {
            perror("can't open the file");
            this->sim_mem::~sim_mem();
            exit(EXIT_FAILURE);
        }
        page_table[0] = new page_descriptor[num_of_pages];
    }
    int i = 0;
    while (i < MEMORY_SIZE) {
        main_memory[i] = '0';
        i++;
    }
    i = 0;
    while (i < swap_size) {
        if (write(this->swapfile_fd, "0", 1) == -1) {
            perror("Can't write to swap file");
            this->sim_mem::~sim_mem();
            exit(EXIT_FAILURE);
        }
        i++;
    }

    for (int j = 0; j < num_of_process; j++) {
        for (int k = 0; k < num_of_pages; k++) {
            page_table[j][k].V = 1;
            page_table[j][k].D = 0;
            page_table[j][k].frame = 1;
            page_table[j][k].swap_index = -1;
            if (k < textPages)
                page_table[j][k].P = 0;
            else
                page_table[j][k].P = 1;
        }
    }

}

/**************************************************************************************/
sim_mem::~sim_mem() {
    delete[] page_table[0];
    if (num_of_proc == 2)
        delete[] page_table[1];
    delete[] page_table;

    if ((close(swapfile_fd)) == -1 || (close(program_fd[0])) == -1) {
        perror("close Failed");
        exit(EXIT_FAILURE);
    }
    if (num_of_proc == 2) {
        if ((close(program_fd[1])) == -1) {
            perror("close Failed");
            exit(EXIT_FAILURE);
        }
    }
}


char sim_mem::load(int process_id, int address) {
    if (address < 0)
        return '\0';
    process_id--;
    int offset = address % page_size;
    int VA = address / page_size;
    int PA = -1;
    int frame;
    char val = '\0';
    if (page_table[process_id][VA].V == 1) {
        frame = page_table[process_id][VA].frame;
        PA = offset + (frame * page_size);
        val=main_memory[PA];
    }else{
        if(page_table[process_id][VA].P == 0){
            char temp[page_size];
            lseek(program_fd[process_id],page_size*VA,SEEK_SET);
            if (read(program_fd[process_id], temp, page_size) != page_size) {
                perror("Read From executable File Is Failed");
                return '\0';
            }
            frame=page_table[process_id][VA].frame;


        }
    }


    return val;
}

void sim_mem::store(int process_id, int address, char value) {
    if (address < 0)
        return;
    process_id--;
    int offset = address % page_size;
    int VA = address / page_size;
    int PA = -1;
    int frame;
    if (page_table[process_id][VA].V == 1) {
        frame = page_table[process_id][VA].frame;
        PA = offset + (frame * page_size);
        main_memory[PA]=value;
    }
}


/**************************************************************************************/
void sim_mem::print_memory() {
    int i;
    printf("\n Physical memory\n");
    for (i = 0; i < MEMORY_SIZE; i++) {
        printf("[%c]\n", main_memory[i]);
    }
}

/************************************************************************************/
void sim_mem::print_swap() {
    char *str = (char *) malloc(this->page_size * sizeof(char));
    int i;
    printf("\n Swap memory\n");
    lseek(swapfile_fd, 0, SEEK_SET); // go to the start of the file
    while (read(swapfile_fd, str, this->page_size) == this->page_size) {
        for (i = 0; i < page_size; i++) {
            printf("%d - [%c]\t", i, str[i]);
        }
        printf("\n");
    }
}

/***************************************************************************************/
void sim_mem::print_page_table() {
    int i;
    for (int j = 0; j < num_of_proc; j++) {
        printf("\n page table of process: %d \n", j + 1);
        printf("Valid\t Dirty\t Permission \t Frame\t Swap index\n");
        for (i = 0; i < num_of_pages; i++) {
            printf("[%d] \t [%d] \t [%d] \t\t\t [%d] \t [%d]\n",
                   page_table[j][i].V,
                   page_table[j][i].D,
                   page_table[j][i].P,
                   page_table[j][i].frame,
                   page_table[j][i].swap_index);
        }
    }
}








